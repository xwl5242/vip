(function($){
	$(function(){
        // 获取接口配置json文件数据，并初始化下拉框
	    $.getJSON('config.json', function(data){
	        //接口地址list
	        base_url_list = data.base_url_list;
	        html = ''
	        for(var i=0;i<base_url_list.length;i++){
	            sel = i==0?'selected':'';
	            html += '<option '+sel+' value="'+base_url_list[i]+'">接口'+(i+1)+'</option>'
            }
            $('#url_interface').append(html)
            //背景随机变化
            let bk_num = data.background_num;
	        let bk_index = Math.floor((Math.random()*bk_num));
            $('.header').addClass('bk'+bk_index);
        });
	    //"解析"按钮点击事件
        $('#anly_btn').click(function(){
            let base_url = $('#url_interface').val();
            let vip_url = $('#vip_url').val();
            if(!vip_url){
                layer.msg('请输入vip视频地址...');
                return;
            }
            $(".player_tips").hide();
            $(".player_helper").show();
            localStorage.setItem('VIP_URL', base_url+vip_url)
            $("#player_frame").attr("src", base_url+vip_url);
        });
	    //复制链接
        $('#copy-vip-url').click(function(){
            new ClipboardJS('#copy-vip-url', {
                text: function(){
                    return localStorage.getItem('VIP_URL')
                }
            });
            layer.msg('复制成功！')
        });
	    //全屏
        $('#full-screen').click(function(){
            if (screenfull.enabled) {
                const target = $('#player_frame')[0];
                screenfull.request(target);
            }
        });
	    //设置player的高度
        player_h = $('.intro').height()-$('#player_head').height()-$('form').height()-100;
        $('.player').height(player_h+'px');

    });
})(jQuery);
